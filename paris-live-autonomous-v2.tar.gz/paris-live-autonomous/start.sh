#!/bin/bash
#
# 🚀 LANCEMENT RAPIDE
# Script tout-en-un pour démarrer rapidement
#

# Activer l'environnement virtuel
if [ -d ".venv" ]; then
    source .venv/bin/activate
fi

# Afficher menu
echo "======================================================================"
echo "⚽ SYSTÈME DE PRÉDICTION FOOTBALL V2.0"
echo "======================================================================"
echo ""
echo "Que voulez-vous faire ?"
echo ""
echo "  1. 🎯 Monitoring d'un match en direct"
echo "  2. 🔄 Mise à jour hebdomadaire (scraping + whitelists)"
echo "  3. 📊 Scraper une ligue spécifique"
echo "  4. 🎯 Générer/Régénérer les whitelists"
echo "  5. 📚 Lire la documentation"
echo "  6. 🔧 Configuration Telegram"
echo "  7. ❌ Quitter"
echo ""
read -p "Votre choix (1-7) : " choice

case $choice in
    1)
        echo ""
        echo "🎯 Lancement du monitoring..."
        python3 monitor_live.py
        ;;
    2)
        echo ""
        echo "🔄 Mise à jour complète (peut prendre 20-30 min)..."
        ./update_weekly.sh
        ;;
    3)
        echo ""
        echo "📊 Ligues disponibles : france, germany, germany2, england, netherlands2, bolivia, bulgaria, portugal"
        read -p "Quelle ligue ? : " league
        echo ""
        echo "🔍 Scraping de $league..."
        python3 scrape_all_leagues_auto.py --league "$league" --workers 2
        ;;
    4)
        echo ""
        echo "🎯 Génération de toutes les whitelists..."
        python3 generate_top_teams_whitelist.py --all --threshold 65 --min-matches 4
        ;;
    5)
        echo ""
        echo "📚 Documentation disponible :"
        echo "   • README.md - Guide rapide"
        echo "   • GUIDE_AUTONOME_COMPLET.md - Guide détaillé"
        echo "   • PACKAGE_CONTENU.md - Contenu du package"
        echo ""
        read -p "Ouvrir README.md ? (o/n) : " open_readme
        if [[ $open_readme == "o" || $open_readme == "O" ]]; then
            if [[ "$OSTYPE" == "darwin"* ]]; then
                open README.md
            else
                cat README.md
            fi
        fi
        ;;
    6)
        echo ""
        echo "🔧 Configuration Telegram..."
        ${EDITOR:-nano} telegram_config.json
        echo ""
        echo "✅ Configuration sauvegardée"
        ;;
    7)
        echo ""
        echo "👋 Au revoir !"
        exit 0
        ;;
    *)
        echo ""
        echo "❌ Choix invalide"
        exit 1
        ;;
esac

echo ""
echo "======================================================================"
echo "✅ Terminé !"
echo "======================================================================"
