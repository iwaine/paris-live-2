# ⚽ Système de Prédiction Football V2.0

## 🚀 Démarrage Rapide

### 1. Installation des dépendances
```bash
pip3 install requests beautifulsoup4 lxml
```

### 2. Configuration Telegram
Éditez `telegram_config.json` avec vos identifiants Telegram

### 3. Première utilisation
```bash
# Scraper une ligue
python3 scrape_all_leagues_auto.py --league portugal --workers 2

# Générer les patterns
cd football-live-prediction
python3 build_team_recurrence_stats.py
cd ..

# Générer la whitelist
python3 generate_top_teams_whitelist.py --league portugal
```

### 4. Monitoring en direct
```bash
python3 monitor_live.py
```

## 📚 Documentation complète

Consultez `GUIDE_AUTONOME_COMPLET.md` pour le guide détaillé.

## 🔄 Mise à jour hebdomadaire

```bash
./update_weekly.sh
```

## 📊 Ligues supportées

- france (Ligue 1)
- germany (Bundesliga)
- germany2 (Bundesliga 2)
- england (Premier League)
- netherlands2 (Eredivisie)
- bolivia (Liga Boliviana)
- bulgaria (Bulgarian League)
- portugal (Liga Portugal)

## 🎯 Méthodologie

- **Intervalles surveillés :** 31-45' et 76-90'
- **Seuil de validation :** 65%
- **Formula MAX :** Meilleur pattern entre HOME/AWAY
- **Récurrence :** Totale + Récente (3 derniers matchs)
- **Buts comptés :** Marqués + Encaissés
